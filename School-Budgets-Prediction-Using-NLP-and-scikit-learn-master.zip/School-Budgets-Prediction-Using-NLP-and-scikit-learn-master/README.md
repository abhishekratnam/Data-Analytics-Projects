# School-Budgets-Prediction-Using-NLP-and-scikit-learn
Its my work regarding building a model using different pipeline,classifiers,and a logistic regression model.
